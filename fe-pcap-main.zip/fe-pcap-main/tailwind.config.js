module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      screens: {
        "3xl": "1600px",
        "4xl": "1800px",
        "5xl": "2000px",
      },
      fontFamily: {
        outfit: ["Outfit", "sans-serif"],
      },
      keyframes: {
        spinReverse: {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(-360deg)" },
        },
        spinClockwise: {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" },
        },
      },
      animation: {
        spinReverse: "spinReverse 120s linear infinite",
        spinClockwise: "spinClockwise 120s linear infinite",
      },
    },
  },
  plugins: [],
};
