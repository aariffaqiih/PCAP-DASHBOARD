import { Route } from "@solidjs/router";
import Login from "../pages/login/login";
import Dashboard from "../pages/dashboard/dashboard";
import Transactions from "../pages/transactions/transactions";

const AppRoutes = () => {
  return (
    <>
      <Route path="/login" component={Login} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/transactions" component={Transactions} />
    </>
  );
};

export default AppRoutes;
