import { Component, createSignal } from "solid-js";
import { useNavigate } from "@solidjs/router";
import { setUsername } from "../../stores/authStore";
import logotsel from "../../assets/svg/logotsel.svg";
import logo from "../../assets/svg/logo.svg";
import "remixicon/fonts/remixicon.css";

const Login: Component = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = createSignal(false);
  const [inputUsername, setInputUsername] = createSignal("");

  const handleLogin = (e: Event) => {
    e.preventDefault();
    setUsername(inputUsername());
    navigate("/dashboard");
  };

  return (
    <div class="text-white font-outfit flex flex-col lg:flex-row-reverse h-screen bg-[#110F17] items-center overflow-y-hidden">
      <div class="z-10 flex flex-1 flex-col justify-center w-full lg:w-1/2">
        <div class="z-0 xl:right-5 2xl:right-28 w-[722px] h-[722px] flex flex-col fixed animate-spinReverse">
          <div class="w-full flex justify-between absolute top-0">
            <img src="/src/assets/svg/ornaments/SmallEllipse.svg" class="animate-spinClockwise" />
            <div class=""></div>
          </div>
          <div class="w-full flex justify-between absolute bottom-0">
            <div class=""></div>
            <img src="/src/assets/svg/ornaments/BigEllipse.svg" class="animate-spinClockwise" />
          </div>
        </div>

        <div
          class="mx-auto backdrop-blur-2xl w-[482px] h-screen lg:h-[539px] rounded-[20px] flex flex-col items-center justify-center"
          style={{
            "background-image": "url('/src/assets/svg/ornaments/PCAP-LOGIN-GLASSMORPHISM.svg')",
            "background-size": "fit",
            "background-repeat": "no-repeat",
            "background-position": "center",
          }}
        >
          <h2 class="text-4xl font-semibold w-[400px]">Login</h2>
          <p class="text-xs font-medium mt-2 mb-4 w-[400px]">Fill Username & Password!</p>

          <form onSubmit={handleLogin}>
            <div class="mb-6 w-[400px]">
              <input placeholder="Username" type="text" class="focus:outline-none w-full p-4 rounded-xl bg-transparent border-[1px] border-white text-xl" onInput={(e) => setInputUsername(e.currentTarget.value)} required />
            </div>

            <div class="mb-3 w-[400px] relative">
              <input placeholder="Password" type={showPassword() ? "text" : "password"} class="focus:outline-none w-full p-4 rounded-xl bg-transparent border-[1px] border-white text-xl" required />
              <button type="button" class="absolute !text-xl top-[18px] right-5 flex items-center " onClick={() => setShowPassword(!showPassword())}>
                <i class={showPassword() ? "ri-eye-line" : "ri-eye-off-line"}></i>
              </button>
            </div>

            <div class="flex items-center justify-between mb-6 w-[400px]">
              <label class="flex items-center relative cursor-pointer">
                <input
                  type="checkbox"
                  class="appearance-none h-5 w-5 border border-gray-400 rounded-md bg-transparent checked:bg-gradient-to-r checked:from-[#FABC3F] checked:via-[#E85C0D] checked:to-[#C7253E] checked:border-none focus:outline-none transition-all duration-300"
                />
                <i class="ri-check-fill absolute left-0.5 text-[#110F17] font-black transition-all duration-300 checked:pointer-events-none"></i>
                <span class="ml-2">Remember me</span>
              </label>
            </div>

            <button type="submit" class="hover:brightness-75 transition-all w-[400px] h-[53px] rounded-2xl bg-gradient-to-r from-[#FABC3F] via-[#E85C0D] to-[#E85C0D] text-xl font-semibold">
              Login
            </button>

            <div class="mt-3 text-center w-[400px]">
              <a href="#" class="text-base hover:underline">
                Forgot password?
              </a>
            </div>
          </form>
        </div>
      </div>

      <div class="z-10 flex flex-1 flex-col invisible lg:visible justify-center items-center w-full lg:w-1/2">
        <div class="flex items-center">
          <img src={logotsel} alt="Telkomsel Logo" />
          <h2 class="text-xl font-normal">EDC Monitoring Dashboard</h2>
        </div>
        <img src={logo} alt="Credit Cards" class="-mt-7 w-[456px] h-[456px]" />
      </div>
    </div>
  );
};

export default Login;
