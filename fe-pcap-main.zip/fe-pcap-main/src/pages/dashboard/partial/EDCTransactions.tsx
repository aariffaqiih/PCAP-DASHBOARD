import { Component, createSignal, onMount } from "solid-js";

const EDCTransactions: Component = () => {
  const [success, setSuccess] = createSignal(20000);
  const [failed, setFailed] = createSignal(16000);

  const total = success() + failed();
  const successPercentage = (success() / total) * 100;
  const failedPercentage = (failed() / total) * 100;

  const isSuccessLarger = success() >= failed();

  const floatingAnimation = {
    animation: "floating 10s ease-in-out infinite",
  };

  const floatingAnimation2 = {
    animation: "floating2 10s ease-in-out infinite",
  };

  const styles = `
    @keyframes floating {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-8px); }
    }

    @keyframes floating2 {
      100%, 0% { transform: translateY(0); }
      50% { transform: translateY(8px); }
    }
  `;

  const successGradient = "radial-gradient(72.45% 72.45% at 27.78% 24.07%, #A2B6FF 0%, #466EFF 60.46%, #194BFF 79.62%, #2B59FF 100%)";
  const failedGradient = "radial-gradient(95.29% 95.29% at 25.33% 10.89%, #FABC3F 0%, #E85C0D 45.39%, #C7253E 75%, #821131 100%)";

  return (
    <div class="bg-[#1F1E29] relative overflow-hidden">
      <style>{styles}</style>
      <div class="flex justify-between items-center">
        <div class="bg-[#FFFFFF0A] !min-h-64 !min-w-64 rounded-full relative flex items-center justify-center">
          <div class={` ${isSuccessLarger ? "z-20" : "z-10"} transition-transform duration-500 ease-in-out`} style={floatingAnimation}>
            <div
              class={`rounded-full shadow-[0_10px_20px_rgba(25,75,255,0.3)] ${isSuccessLarger ? "scale-110" : "scale-100"}`}
              style={{
                background: successGradient,
                width: "112px",
                height: "112px",
              }}
            ></div>
            <div class="absolute inset-0 flex flex-col items-center justify-center text-white">
              <p class="text-xs">Success</p>
              <p class="text-lg">{successPercentage.toFixed(2)}%</p>
            </div>
          </div>

          <div class={`${isSuccessLarger ? "z-10" : "z-20"} transition-transform duration-500 ease-in-out`} style={floatingAnimation2}>
            <div
              class={`rounded-full shadow-[0_10px_20px_rgba(232,95,13,0.3)] ${!isSuccessLarger ? "scale-110" : "scale-100"}`}
              style={{
                background: failedGradient,
                width: "108px",
                height: "108px",
              }}
            ></div>
            <div class="absolute inset-0 flex flex-col items-center justify-center text-white">
              <p class="text-xs">Failed</p>
              <p class="text-lg">{failedPercentage.toFixed(2)}%</p>
            </div>
          </div>
        </div>

        <div class="text-white w-full ml-16">
          <p class="text-sm text-[#C5C4C7]">Total Transaction</p>
          <p class="text-xl text=[#F6F6F6] font-medium">{total.toLocaleString()}</p>
          <div class="w-full my-5 h-[1px] bg-[#FFFFFF1A]"></div>
          <div class="flex items-center mb-2">
            <div
              class="min-w-3 min-h-3 rounded-full mr-2"
              style={{
                background: successGradient,
                "box-shadow": "0px 0px 10px rgba(0,159,255,0.2)",
              }}
            ></div>
            <p class="text-base text-[#C5C4C7]">Success Transaction</p>
            <p class="text-base ml-auto">{success().toLocaleString()}</p>
          </div>
          <div class="flex items-center">
            <div
              class="min-w-3 min-h-3 rounded-full mr-2"
              style={{
                background: failedGradient,
                "box-shadow": "0px 0px 10px rgba(255,75,75,0.2)",
              }}
            ></div>
            <p class="text-base text-[#C5C4C7]">Failed Transaction</p>
            <p class="text-base ml-auto">{failed().toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EDCTransactions;
