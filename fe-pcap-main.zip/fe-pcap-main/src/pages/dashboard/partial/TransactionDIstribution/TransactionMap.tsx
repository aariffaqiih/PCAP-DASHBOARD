import type { Component } from "solid-js";
import { createEffect } from "solid-js";

import * as am5 from "@amcharts/amcharts5";
import * as am5map from "@amcharts/amcharts5/map";
import am5geodata_indonesiaLow from "@amcharts/amcharts5-geodata/indonesiaLow";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

const TransactionMap: Component = () => {
  let refDiv: any;
  let root: any;

  createEffect(() => {
    if (root) {
      root.dispose();
    }
    Chart();
  });

  let colors: any = {
    YELLOW: am5.color("#FEFF9F"),
    GREEN: am5.color("#A0D683"),
    DARKGREEN: am5.color("#72BF78"),
  };

  const getColorBasedOnValue = (value: number) => {
    if (value > 90000) return colors.DARKGREEN;
    else if (value >= 50000) return colors.GREEN;
    else return colors.YELLOW;
  };

  const idMapas = [
    { id: "ID-AC", value: Math.floor(Math.random() * 100000) },
    { id: "ID-SU", value: Math.floor(Math.random() * 100000) },
    { id: "ID-RI", value: Math.floor(Math.random() * 100000) },
    { id: "ID-KR", value: Math.floor(Math.random() * 100000) },
    { id: "ID-SB", value: Math.floor(Math.random() * 100000) },
    { id: "ID-BE", value: Math.floor(Math.random() * 100000) },
    { id: "ID-JA", value: Math.floor(Math.random() * 100000) },
    { id: "ID-BB", value: Math.floor(Math.random() * 100000) },
    { id: "ID-SS", value: Math.floor(Math.random() * 100000) },
    { id: "ID-LA", value: Math.floor(Math.random() * 100000) },
    { id: "ID-KT", value: Math.floor(Math.random() * 100000) },
    { id: "ID-KU", value: Math.floor(Math.random() * 100000) },
    { id: "ID-KS", value: Math.floor(Math.random() * 100000) },
    { id: "ID-KB", value: Math.floor(Math.random() * 100000) },
    { id: "ID-KI", value: Math.floor(Math.random() * 100000) },
    { id: "ID-SN", value: Math.floor(Math.random() * 100000) },
    { id: "ID-ST", value: Math.floor(Math.random() * 100000) },
    { id: "ID-SR", value: Math.floor(Math.random() * 100000) },
    { id: "ID-SG", value: Math.floor(Math.random() * 100000) },
    { id: "ID-GO", value: Math.floor(Math.random() * 100000) },
    { id: "ID-SA", value: Math.floor(Math.random() * 100000) },
    { id: "ID-MU", value: Math.floor(Math.random() * 100000) },
    { id: "ID-MA", value: Math.floor(Math.random() * 100000) },
    { id: "ID-PB", value: Math.floor(Math.random() * 100000) },
    { id: "ID-PA", value: Math.floor(Math.random() * 100000) },
    { id: "ID-JK", value: Math.floor(Math.random() * 100000) },
    { id: "ID-BT", value: Math.floor(Math.random() * 100000) },
    { id: "ID-JT", value: Math.floor(Math.random() * 100000) },
    { id: "ID-YO", value: Math.floor(Math.random() * 100000) },
    { id: "ID-JI", value: Math.floor(Math.random() * 100000) },
    { id: "ID-BA", value: Math.floor(Math.random() * 100000) },
    { id: "ID-NT", value: Math.floor(Math.random() * 100000) },
    { id: "ID-NB", value: Math.floor(Math.random() * 100000) },
    { id: "ID-JB", value: Math.floor(Math.random() * 100000) },
  ];

  let indexMap = idMapas.map((item) => ({
    ...item,
    polygonSettings: {
      fill: getColorBasedOnValue(item.value),
      stroke: getColorBasedOnValue(item.value),
    },
  }));

  let Chart = () => {
    let root = am5.Root.new(refDiv);
    root._logo?.dispose();

    root.setThemes([am5themes_Animated.new(root)]);

    let chart = root.container.children.push(
      am5map.MapChart.new(root, {
        panX: "translateX",
        panY: "translateY",
        projection: am5map.geoMercator(),
      })
    );

    let polygonSeries = chart.series.push(
      am5map.MapPolygonSeries.new(root, {
        geoJSON: am5geodata_indonesiaLow,
        exclude: ["MY-13", "MY-12", "BN", "TL"],
      })
    );

    polygonSeries.mapPolygons.template.setAll({
      tooltipText: "{name} - {value}",
      toggleKey: "active",
      interactive: true,
      templateField: "polygonSettings",
      fillOpacity: 0.5,
      strokeWidth: 3,
    });

    polygonSeries.mapPolygons.template.states.create("hover", {
      fillOpacity: 1,
    });

    polygonSeries.data.setAll(indexMap);

    chart.chartContainer.get("background")?.events.on("click", function () {
      chart.goHome();
    });

    chart.appear(1000, 100);
  };

  return <div ref={refDiv} style={{ width: "100%", height: "500px" }} />;
};

export default TransactionMap;
