import { Component } from "solid-js";
import TransactionDistributionChart from "./TransactionDistributionChart";
import FailedCauseCodeChart from "./FailedCauseCodeChart";
import TransactionDetailsTable from "./TransactionDetailsTable";

const TransactionMapPopup: Component<{ onClose: () => void }> = (props) => {
  return (
    <div class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div class="bg-black backdrop-blur-sm border-[1px] border-neutral-200 bg-opacity-10 p-6 rounded-2xl w-11/12 h-5/6  overflow-y-scroll">
        <div class="flex justify-between items-center mb-4">
          <div class="flex flex-col gap-2">
            <h2 class="text-lg font-semibold text-white">Transaction Distribution</h2>
            <p class="text-[#C5C4C7] text-xs">Area 1 All</p>
          </div>

          <div class="flex gap-4">
            <select class="bg-[#1F1E29] border-[1px] border-[#3E3E47] px-3 py-2 rounded-full text-white focus:outline-none">
              <option>ALL</option>
              <option>Success</option>
              <option>Failed</option>
            </select>
            <button onClick={props.onClose} class="text-white text-lg">
              <img src="/src/assets/svg/globalicon/close.svg" alt="Close" />
            </button>
          </div>
        </div>

        <div class="flex flex-col space-y-4">
          <div class="flex lg:flex-row flex-col space-x-4">
            <div class="bg-black border border-neutral-500 p-4 rounded-xl flex-1">
              <h3 class="text-md font-semibold text-white mb-3">Transaction Distribution Trend</h3>
              <TransactionDistributionChart />
            </div>

            <div class="bg-black border border-neutral-500 p-4 rounded-xl flex-1">
              <h3 class="text-md font-semibold text-white mb-3">Failed Cause Code Distribution</h3>
              <FailedCauseCodeChart />
            </div>
          </div>

          <div class="bg-black border border-neutral-500 p-4 rounded-xl">
            <div class="flex justify-between items-center mb-4">
              <h3 class="text-md font-semibold text-white mb-3">Transaction Details</h3>
              <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
            </div>
            <TransactionDetailsTable />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionMapPopup;
