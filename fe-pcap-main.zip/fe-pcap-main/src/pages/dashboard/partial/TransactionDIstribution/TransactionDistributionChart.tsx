import { Component, For, onMount } from "solid-js";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

const TransactionDistributionTrendChart: Component = () => {
  let chartDiv: HTMLDivElement;

  const data = [
    { date: "2024/09/01", success: 200, failed: 100 },
    { date: "2024/09/02", success: 300, failed: 150 },
    { date: "2024/09/03", success: 350, failed: 175 },
    { date: "2024/09/04", success: 450, failed: 200 },
    { date: "2024/09/05", success: 500, failed: 250 },
    { date: "2024/09/06", success: 700, failed: 300 },
    { date: "2024/09/07", success: 800, failed: 400 },
    { date: "2024/09/08", success: 900, failed: 450 },
  ];

  const causeLabels = [
    { name: "Success", fieldName: "success", color: "#4379F2" },
    { name: "Failed", fieldName: "failed", color: "#EFDD00" },
  ];

  onMount(() => {
    const root = am5.Root.new(chartDiv);
    root._logo?.dispose();

    root.setThemes([am5themes_Animated.new(root)]);

    const chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        layout: root.verticalLayout,
        panX: false,
        panY: false,
        wheelX: "panX",
        wheelY: "zoomX",
        paddingLeft: 0,
      })
    );

    const xAxis = chart.xAxes.push(
      am5xy.CategoryAxis.new(root, {
        categoryField: "date",
        renderer: am5xy.AxisRendererX.new(root, {
          minGridDistance: 30,
          inside: true,
        }),
      })
    );
    xAxis.data.setAll(data);

    xAxis.get("renderer").labels.template.setAll({
      fontSize: "14px",
      fill: am5.color("#ffffff"),
      dy: 21,
    });

    const yAxis = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        renderer: am5xy.AxisRendererY.new(root, {
          strokeOpacity: 0.1,
        }),
        min: 0,
      })
    );

    yAxis.get("renderer").labels.template.setAll({
      fontSize: "12px",
      fill: am5.color("#ffffff"),
    });

    function createSeries(name: string, fieldName: keyof (typeof data)[0], color: string) {
      const series = chart.series.push(
        am5xy.ColumnSeries.new(root, {
          name,
          stacked: true,
          xAxis,
          yAxis,
          valueYField: fieldName,
          categoryXField: "date",
          fill: am5.color(color),
        })
      );

      series.columns.template.setAll({
        width: am5.percent(35),
        tooltipText: "{name}: {valueY}",
        fillOpacity: 1,
        strokeOpacity: 0,
        cornerRadiusTL: 6,
        cornerRadiusTR: 6,
        cornerRadiusBL: 6,
        cornerRadiusBR: 6,
      });

      series.data.setAll(data);
    }

    causeLabels.forEach((label) => {
      createSeries(label.name, label.fieldName as keyof (typeof data)[0], label.color);
    });


    return () => root.dispose();
  });

  const legendData = causeLabels.map((legend) => (
    <div class="flex items-center">
      <div class="flex items-center">
        <div class="!w-3 !h-3 rounded-full mr-2" style={`background:${legend.color}`} />
        <span class="text-sm text-white">{legend.name}</span>
      </div>
    </div>
  ));

  return (
    <div class="flex justify-center w-full flex-col items-center">
      <div ref={(el) => (chartDiv = el)} class="w-full h-60 mb-3"></div>
      <div class="flex flex-wrap gap-3 justify-center">
        <For each={legendData}>{(legend: any) => legend}</For>
      </div>
    </div>
  );
};

export default TransactionDistributionTrendChart;
