import { Component, createSignal } from "solid-js";
import CauseCodeDetailsChart from "./CauseCodeDetailsChart";
import CauseCodeDistributionChart from "./CauseCodeDistributionChart";
import FailedSessionDetailsTable from "./FailedSessionDetailsTable";

const TransactionFailed: Component<{ onClose: () => void }> = (props) => {
  const [date, setDate] = createSignal("");

  return (
    <div class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div class="bg-black backdrop-blur-sm border-[1px] border-neutral-200 bg-opacity-10 p-6 rounded-2xl w-11/12 h-5/6  overflow-y-scroll">
        <div class="flex justify-between items-start mb-4">
          <div class="flex flex-col">
                    <div class="flex flex-col gap-2">
              <h2 class="text-lg font-semibold text-white">Session Success Rate Details</h2>
              <h2 class="text-xs font-semibold text-[#C5C4C7]">2024-09-19, Failed Session</h2>
            </div>
            <span class="text-white text-sm">{date()}</span>
          </div>

          <button onClick={props.onClose} class="text-white">
            <img src="/src/assets/svg/globalicon/close.svg" alt="Close" />
          </button>
        </div>
        <div>
          <div class="md:hidden lg:block">
            <div class="grid grid-cols-2 gap-4">
              <div class="bg-black p-4 rounded-xl">
                <h3 class="text-md font-semibold text-white mb-3">Cause Code Details</h3>
                <CauseCodeDetailsChart />
              </div>
              <div class="bg-black p-4 rounded-xl">
                <h3 class="text-md font-semibold text-white mb-3">Cause Code Distribution</h3>
                <CauseCodeDistributionChart />
              </div>
              <div class="bg-black p-4 rounded-xl col-span-2">
              <div class="flex justify-between">
                <h3 class="text-md font-semibold text-white mb-3">Failed Session Details</h3>
                <button>
                    <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
                  </button>
                  </div>
                <FailedSessionDetailsTable onTimestampExtracted={setDate} />
              </div>
            </div>
          </div>
          <div class="md:block lg:hidden">
            <div class="flex flex-col gap-4">
              <div class="bg-black p-4 rounded-xl">
                <h3 class="text-md font-semibold text-white mb-3">Cause Code Details</h3>
                <CauseCodeDetailsChart />
              </div>
              <div class="bg-black p-4 rounded-xl">
                <h3 class="text-md font-semibold text-white mb-3">Cause Code Distribution</h3>
                <CauseCodeDistributionChart />
              </div>
              <div class="bg-black p-4 rounded-xl col-span-2">
                <h3 class="text-md font-semibold text-white mb-3">Failed Session Details</h3>
                <FailedSessionDetailsTable onTimestampExtracted={setDate} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionFailed;
