import { createSignal, Component } from "solid-js";

interface RealtimeSessionPopupProps {
  onClose: () => void;
}

const RealtimeTransactionPopup: Component<RealtimeSessionPopupProps> = ({ onClose }) => {
  return (
    <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-[#1F1E29] rounded-xl p-6 w-3/4 max-w-2xl">
        <div class="flex justify-between items-center mb-4">
          <h2 class="text-lg font-semibold text-white"> Data</h2>
          <button onClick={onClose} class="text-white">
            ✖
          </button>
        </div>

        <div class="mb-4">
          <div class="h-60 bg-gray-800 rounded-lg mb-4">Chart Placeholder</div>

          <table class="min-w-full bg-gray-800 text-white rounded-lg">
            <thead>
              <tr>
                <th class="px-4 py-2">Date</th>
                <th class="px-4 py-2">Accepted</th>
                <th class="px-4 py-2">Failed</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="border-t px-4 py-2">2024-09-19</td>
                <td class="border-t px-4 py-2">600</td>
                <td class="border-t px-4 py-2">200</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RealtimeTransactionPopup;
