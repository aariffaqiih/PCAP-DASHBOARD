import { createSignal, Component } from "solid-js";
import AgGridSolid from "ag-grid-solid";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

interface RealtimeSessionPopupProps {
  onClose: () => void;
}

const getRandomElement = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
const generateRandomData = () => ({
  teId: Math.random().toString().slice(2, 18),
  timestamp: new Date().toISOString().replace("T", " ").slice(0, 19) + `, ${Math.floor(Math.random() * 1000000)}`,
  gtpCommand: getRandomElement(["Create Bearer Request", "Delete Bearer Request", "Modify Bearer Request"]),
  status: getRandomElement(["Success", "Failed"]),
  imsi: "08" + Math.floor(1000000000000 + Math.random() * 8999999999999).toString(),
  rootCause: getRandomElement(["Create Session Request", "Modify Bearer Failure", "Delete Bearer Success"]),
  hwDest: `MS-NLB-PhysServer-01_${Math.floor(10 + Math.random() * 90)}:${Math.random().toString(16).slice(2, 6)}`
});

const TransactionAccepted: Component<RealtimeSessionPopupProps> = ({ onClose }) => {
  const [rowData, setRowData] = createSignal(Array.from({ length: 10 }, generateRandomData));

  const columnDefs = [
    { field: "teId", headerName: "TE ID", headerCheckboxSelection: true, checkboxSelection: true, flex: 1, minWidth: 200, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
    { field: "timestamp", headerName: "Timestamp", flex: 2, minWidth: 200, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
    { field: "gtpCommand", headerName: "GTP Command", flex: 1, minWidth: 200, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
    { field: "status", headerName: "Status", flex: 1, minWidth: 100, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: (params: any) => params.value === "Success" ? "text-green-500 font-bold text-center" : "text-red-500 font-bold text-center" },
    { field: "imsi", headerName: "IMSI", flex: 1, minWidth: 150, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
    { field: "rootCause", headerName: "Rootcause", flex: 1, minWidth: 200, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
    { field: "hwDest", headerName: "HW Dest", flex: 1, minWidth: 200, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
  ];

  return (
    <div class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div class="bg-neutral-700 backdrop-blur-md border-[1px] border-neutral-200 bg-opacity-20 p-6 rounded-2xl w-11/12 h-5/6 overflow-y-scroll">
        <div class="flex justify-between items-start mb-6">
          <div>
            <h2 class="text-2xl font-semibold text-white">Session Success Rate Details</h2>
            <p class="text-gray-400">2024-09-19, Success Sessions</p>
          </div>
          <div class="flex gap-4">
            <select class="bg-[#1F1E29] border-[1px] border-[#3E3E47] px-3 py-2 rounded-full text-white focus:outline-none">
              <option>Success Session</option>
              <option>Failed Session</option>
              <option>ALL</option>
            </select>
            <button onClick={onClose} class="text-white text-lg">
              <img src="/src/assets/svg/globalicon/close.svg" alt="Close" />
            </button>
          </div>
        </div>

        <div class="bg-black p-4 rounded-xl">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-md font-semibold text-white">Session Success Rate Details</h3>
            <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
          </div>
          <div class="ag-theme-alpine-dark h-96 rounded-lg">
            <AgGridSolid
              rowData={rowData()}
              columnDefs={columnDefs}
              defaultColDef={{
                sortable: true,
                resizable: true,
              }}
              rowSelection="multiple"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionAccepted;
