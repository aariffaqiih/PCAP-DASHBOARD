import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Dark from "@amcharts/amcharts5/themes/Dark";
import { Component, onCleanup, onMount } from "solid-js";

interface RealtimeChartProps {
  chartId: string;
  onLineClick: (type: string) => void;
}

const RealtimeSessionChart: Component<RealtimeChartProps> = (props) => {
  let root: am5.Root;

  const sessionData = [
    { date: new Date(2024, 8, 19).getTime(), accepted: 600, failed: 200 },
    { date: new Date(2024, 8, 20).getTime(), accepted: 300, failed: 420 },
    { date: new Date(2024, 8, 21).getTime(), accepted: 850, failed: 230 },
    { date: new Date(2024, 8, 22).getTime(), accepted: 500, failed: 440 },
    { date: new Date(2024, 8, 23).getTime(), accepted: 920, failed: 250 },
    { date: new Date(2024, 8, 24).getTime(), accepted: 500, failed: 460 },
    { date: new Date(2024, 8, 25).getTime(), accepted: 980, failed: 270 },
    { date: new Date(2024, 8, 26).getTime(), accepted: 500, failed: 300 },
    { date: new Date(2024, 8, 27).getTime(), accepted: 1100, failed: 120 },
    { date: new Date(2024, 8, 28).getTime(), accepted: 500, failed: 350 },
  ];

  onMount(() => {
    root = am5.Root.new(props.chartId);
    root.setThemes([am5themes_Dark.new(root)]);
    if (root._logo) {
      root._logo.dispose();
    }

    const chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        layout: root.verticalLayout,
        panX: true,
        panY: false,
        wheelX: "panX",
        wheelY: "none",
        background: am5.Rectangle.new(root, {
          fill: am5.color(0x1f1e29),
        }),
      })
    );

    const xAxis = chart.xAxes.push(
      am5xy.DateAxis.new(root, {
        baseInterval: { timeUnit: "day", count: 1 },
        renderer: am5xy.AxisRendererX.new(root, {
          minGridDistance: 50,
          strokeOpacity: 0.2,
          stroke: am5.color(0xffffff),
        }),
      })
    );

    const yAxis = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        renderer: am5xy.AxisRendererY.new(root, {
          strokeOpacity: 0.2,
          stroke: am5.color(0xffffff),
          opposite: true,
        }),
      })
    );

    const series1 = chart.series.push(
      am5xy.SmoothedXYLineSeries.new(root, {
        name: "Request Accepted",
        xAxis: xAxis,
        yAxis: yAxis,
        valueYField: "accepted",
        valueXField: "date",
        stroke: am5.color(0x06d001),
        fill: am5.color(0x06d001),
      })
    );

    series1.strokes.template.setAll({
      strokeWidth: 3,
      shadowColor: am5.color(0x06d001),
      shadowBlur: 30,
      shadowOffsetX: 0,
      shadowOffsetY: 0,
    });

    series1.fills.template.setAll({
      visible: true,
      fillOpacity: 0.6,
    });

    series1.fills.template.set(
      "fillGradient",
      am5.LinearGradient.new(root, {
        stops: [
          { color: am5.color(0x06d001), offset: 0 },
          { color: am5.color(0x1f1e29), offset: 1 },
        ],
      })
    );

    series1.data.setAll(sessionData);
    series1.events.on("click", () => props.onLineClick("accepted"));

    const series2 = chart.series.push(
      am5xy.SmoothedXYLineSeries.new(root, {
        name: "Request Failed",
        xAxis: xAxis,
        yAxis: yAxis,
        valueYField: "failed",
        valueXField: "date",
        stroke: am5.color(0xff1f00),
        fill: am5.color(0xff1f00),
      })
    );

    series2.strokes.template.setAll({
      strokeWidth: 3,
      shadowColor: am5.color(0xff1f00),
      shadowBlur: 30,
      shadowOffsetX: 0,
      shadowOffsetY: 0,
    });

    series2.fills.template.setAll({
      visible: true,
      fillOpacity: 0.6,
    });

    series2.fills.template.set(
      "fillGradient",
      am5.LinearGradient.new(root, {
        stops: [
          { color: am5.color(0xff1f00), offset: 0 },
          { color: am5.color(0x1f1e29), offset: 1 },
        ],
      })
    );

    series2.data.setAll(sessionData);
    series2.events.on("click", () => props.onLineClick("failed"));

    const legend = chart.children.push(
      am5.Legend.new(root, {
        centerX: am5.percent(50),
        x: am5.percent(50),
        centerY: am5.percent(100),
        y: am5.percent(100),
        layout: root.horizontalLayout,
      })
    );

    legend.data.setAll(chart.series.values);

    onCleanup(() => {
      root.dispose();
    });
  });

  return (
    <div class="card">
      <div id={props.chartId} style="width: 100%; height: 300px;"></div>
    </div>
  );
};

export default RealtimeSessionChart;
