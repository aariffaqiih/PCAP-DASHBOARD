import { Component, onMount, For, createEffect } from "solid-js";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

const CauseCodeDistributionChart: Component = () => {
  let chartDiv: HTMLDivElement;

  const causeLabels = [
    { name: "APN Access Denied", color: "#FFEB00", fieldName: "APN_Access_Denied" },
    { name: "Context Not Found", color: "#4379F2", fieldName: "Context_Not_Found" },
    { name: "Missing Unknown APN", color: "#BF2EF0", fieldName: "Missing_Unknown_APN" },
    { name: "New PDN Type", color: "#6CBEC7", fieldName: "New_PDN_Type" },
    { name: "Request Rejected", color: "#FF7203", fieldName: "Request_Rejected" },
    { name: "Unable to Page UE", color: "#F33962", fieldName: "Unable_to_Page_UE" },
    { name: "User Auth Failed", color: "#F8D9CF", fieldName: "User_Auth_Failed" },
  ];

  const data = [
    { area: "AREA 1", APN_Access_Denied: 1030, Context_Not_Found: 80, Missing_Unknown_APN: 60, New_PDN_Type: 40, Request_Rejected: 20, Unable_to_Page_UE: 10, User_Auth_Failed: 5 },
    { area: "AREA 2", APN_Access_Denied: 120, Context_Not_Found: 90, Missing_Unknown_APN: 70, New_PDN_Type: 50, Request_Rejected: 30, Unable_to_Page_UE: 20, User_Auth_Failed: 10 },
    { area: "AREA 3", APN_Access_Denied: 140, Context_Not_Found: 100, Missing_Unknown_APN: 80, New_PDN_Type: 60, Request_Rejected: 40, Unable_to_Page_UE: 30, User_Auth_Failed: 15 },
    { area: "AREA 4", APN_Access_Denied: 160, Context_Not_Found: 110, Missing_Unknown_APN: 90, New_PDN_Type: 70, Request_Rejected: 50, Unable_to_Page_UE: 40, User_Auth_Failed: 20 },
    { area: "AREA 5", APN_Access_Denied: 180, Context_Not_Found: 120, Missing_Unknown_APN: 100, New_PDN_Type: 80, Request_Rejected: 60, Unable_to_Page_UE: 50, User_Auth_Failed: 25 },
    { area: "AREA 6", APN_Access_Denied: 200, Context_Not_Found: 130, Missing_Unknown_APN: 110, New_PDN_Type: 90, Request_Rejected: 70, Unable_to_Page_UE: 60, User_Auth_Failed: 30 },
    { area: "AREA 7", APN_Access_Denied: 220, Context_Not_Found: 140, Missing_Unknown_APN: 120, New_PDN_Type: 100, Request_Rejected: 80, Unable_to_Page_UE: 70, User_Auth_Failed: 35 },
    { area: "AREA 8", APN_Access_Denied: 240, Context_Not_Found: 150, Missing_Unknown_APN: 130, New_PDN_Type: 110, Request_Rejected: 90, Unable_to_Page_UE: 80, User_Auth_Failed: 40 },
  ];

  onMount(() => {
    const root = am5.Root.new(chartDiv);
    root._logo?.dispose();

    root.setThemes([am5themes_Animated.new(root)]);

    const chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        layout: root.verticalLayout,
        panX: false,
        panY: false,
        wheelX: "panX",
        wheelY: "zoomX",
        paddingLeft: 0,
      })
    );

    const xAxis = chart.xAxes.push(
      am5xy.CategoryAxis.new(root, {
        categoryField: "area",
        renderer: am5xy.AxisRendererX.new(root, {
          minGridDistance: 30,
          inside: true,
        }),
      })
    );
    xAxis.data.setAll(data);

    xAxis.get("renderer").labels.template.setAll({
      fontSize: "14px",
      fill: am5.color("#ffffff"),
      dy: 22,
    });

    const yAxis = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        renderer: am5xy.AxisRendererY.new(root, {
          strokeOpacity: 0.1,
        }),
        min: 0,
      })
    );

    yAxis.get("renderer").labels.template.setAll({
      fontSize: "12px",
      fill: am5.color("#ffffff"),
    });

    function createSeries(name: string, fieldName: keyof (typeof data)[0]) {
      const color = causeLabels.find((label) => label.name === name)?.color || "#000";
      const series = chart.series.push(
        am5xy.ColumnSeries.new(root, {
          name,
          stacked: true,
          xAxis,
          yAxis,
          valueYField: fieldName,
          categoryXField: "area",
          fill: am5.color(color),
        })
      );

      series.columns.template.setAll({
        width: am5.percent(35),
        tooltipText: "{name}: {valueY}",
        fillOpacity: 1,
        strokeOpacity: 0,
        cornerRadiusTL: 6,
        cornerRadiusTR: 6,
        cornerRadiusBL: 6,
        cornerRadiusBR: 6,
      });

      series.data.setAll(data);
    }

    causeLabels.forEach((label) => {
      createSeries(label.name, label.fieldName as keyof (typeof data)[0]);
    });

    chart.appear(2000, 100);

    return () => root.dispose();
  });

  const legendData = causeLabels.map((legend) => (
    <div class="flex items-center">
      <div class="flex items-center">
        <div class="!w-3 !h-3 rounded-full mr-2" style={`background:${legend.color}`} />
        <span class="text-sm text-white">{legend.name}</span>
      </div>
    </div>
  ));

  return (
    <div class="flex justify-center w-full flex-col items-center">
      <div ref={(el) => (chartDiv = el)} class="w-full h-60 mb-3"></div>
      <div class="flex flex-wrap gap-3 justify-center">
        <For each={legendData}>{(legend) => legend}</For>
      </div>
    </div>
  );
};

export default CauseCodeDistributionChart;
