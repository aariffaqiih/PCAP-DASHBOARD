import { Component, createSignal, onMount } from "solid-js";
import AgGridSolid from "ag-grid-solid";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

const FailedSessionDetailsTable: Component<{ onTimestampExtracted: (date: string) => void }> = (props) => {
  function generateRandomData() {
    const statuses = ["Failed", "Success"];
    const gtpCommands = ["Delete Bearer Request", "Create Session Request"];
    const rootCauses = ["APN Access Denied", "Network Timeout"];
    const hwDests = ["MS-NLB-PhysServer-OL17:e8:00", "MS-NLB-PhysServer-OL18:e9:01"];

    const randomTeid = () => Math.floor(Math.random() * 1e16).toString();
    const randomIMSI = () => `0818${Math.floor(1e6 + Math.random() * 9e6)}`;

    return Array.from({ length: 5 }, () => ({
      teid: randomTeid(),
      timestamp: new Date().toISOString().replace("T", " ").split(".")[0],
      gtpCommand: gtpCommands[Math.floor(Math.random() * gtpCommands.length)],
      status: statuses[Math.floor(Math.random() * statuses.length)],
      imsi: randomIMSI(),
      rootcause: rootCauses[Math.floor(Math.random() * rootCauses.length)],
      hwDest: hwDests[Math.floor(Math.random() * hwDests.length)],
    }));
  }

  const [rowData] = createSignal(generateRandomData());

  const columnDefs = [
    {
      field: "teid",
      headerName: "TE ID",
      checkboxSelection: true,
      headerCheckboxSelection: true,
      flex: 1,
      minWidth: 200,
      headerClass: "bg-gray-500 text-white text-center font-semibold px-4 py-3 font-outfit",
      cellClass: "text-white text-center px-4 py-2 font-outfit",
    },
    {
      field: "timestamp",
      headerName: "Timestamp",
      flex: 2,
      minWidth: 250,
      headerClass: "bg-gray-500 text-white text-center font-semibold px-4 py-3 font-outfit",
      cellClass: "text-white text-center px-4 py-2 font-outfit",
    },
    {
      field: "gtpCommand",
      headerName: "GTP Command",
      flex: 1,
      minWidth: 200,
      headerClass: "bg-gray-500 text-white text-center font-semibold px-4 py-3 font-outfit",
      cellClass: "text-white text-center px-4 py-2 font-outfit",
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 100,
      headerClass: "bg-gray-500 text-white text-center font-semibold px-4 py-3 font-outfit",
      cellClass: (params: { value: string }) => (params.value === "Failed" ? "text-red-500 font-bold text-center px-4 py-2 font-outfit" : "text-green-500 font-bold text-center px-4 py-2 font-outfit"),
    },
    {
      field: "imsi",
      headerName: "IMSI",
      flex: 1,
      minWidth: 150,
      headerClass: "bg-gray-500 text-white text-center font-semibold px-4 py-3 font-outfit",
      cellClass: "text-white text-center px-4 py-2 font-outfit",
    },
    {
      field: "rootcause",
      headerName: "Rootcause",
      flex: 1,
      minWidth: 200,
      headerClass: "bg-gray-500 text-white text-center font-semibold px-4 py-3 font-outfit",
      cellClass: "text-white text-center px-4 py-2 font-outfit",
    },
    {
      field: "hwDest",
      headerName: "HW Dest",
      flex: 2,
      minWidth: 300,
      headerClass: "bg-gray-500 text-white text-center font-semibold px-4 py-3 font-outfit",
      cellClass: "text-white text-center px-4 py-2 font-outfit",
    },
  ];

  const gridOptions = {
    rowHeight: 50,
    headerHeight: 50,
    domLayout: "autoHeight" as "autoHeight",
    animateRows: true,
  };

  return (
    <div class="ag-theme-alpine-dark font-outfit" style={{ width: "100%", height: "auto", padding: "1rem" }}>
      <AgGridSolid rowData={rowData()} columnDefs={columnDefs} gridOptions={gridOptions} rowSelection="multiple" suppressRowClickSelection={true} />
    </div>
  );
};

export default FailedSessionDetailsTable;
