import type { Component } from "solid-js";
import { createEffect, For } from "solid-js";
import * as am5 from "@amcharts/amcharts5";
import * as am5percent from "@amcharts/amcharts5/percent";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

interface PieData {
  name: string;
  value: number;
}

const CauseCodeDetailsChart: Component = () => {
  let refDiv: any;
  let root: any;

  const pieData: PieData[] = [
    { name: "APN Access Denied", value: 16171 },
    { name: "Context Not Found", value: 16171 },
    { name: "Missing Unknown APN", value: 16171 },
    { name: "New PDN Type", value: 16171 },
    { name: "Request Rejected", value: 16171 },
    { name: "Unable to Page UE", value: 10828 },
    { name: "User Auth Failed", value: 9000 },
  ];

  createEffect(() => {
    if (root) {
      root.dispose();
    }
    Chart();
  });

  const Chart = () => {
    root = am5.Root.new(refDiv);
    let total = pieData.reduce((acc, cur) => acc + cur.value, 0);

    const formattedTotal = new Intl.NumberFormat("de-DE").format(total);

    root._logo?.dispose();
    root.setThemes([am5themes_Animated.new(root)]);

    let chart = root.container.children.push(
      am5percent.PieChart.new(root, {
        layout: root.verticalLayout,
        innerRadius: am5.percent(85),
        radius: am5.percent(86),
      })
    );

    let series = chart.series.push(
      am5percent.PieSeries.new(root, {
        valueField: "value",
        categoryField: "name",
        alignLabels: true,
      })
    );

    series.slices.template.setAll({
      cornerRadius: 10,
      stroke: am5.color("#000000"),
      strokeWidth: 4,
    });

    let colors = series.get("colors");
    if (colors) {
      colors.set("colors", [am5.color("#FFEB00"), am5.color("#4379F2"), am5.color("#BF2EF0"), am5.color("#6CBEC7"), am5.color("#FF7203"), am5.color("#F33962"), am5.color("#F8D9CF")]);
    }

    chart.seriesContainer.children.push(
      am5.Circle.new(root, {
        radius: 60,
        fill: am5.color("#31303A"),
        centerY: am5.p50,
        centerX: am5.p50,
      })
    );

    chart.seriesContainer.children.push(
      am5.Label.new(root, {
        fill: am5.color("#fff"),
        textAlign: "center",
        centerY: am5.p50,
        centerX: am5.p50,
        text: `[fontSize:24px fontWeight:700 fontFamily: "Outfit"]Total\n${formattedTotal}[/]`,
      })
    );

    series.data.setAll(pieData);
  };

  const formatValue = (value: number) => new Intl.NumberFormat("de-DE").format(value);

  const colorLegend = pieData.map((item, index) => {
    let color;
    switch (index) {
      case 0:
        color = "#FFEB00";
        break;
      case 1:
        color = "#4379F2";
        break;
      case 2:
        color = "#BF2EF0";
        break;
      case 3:
        color = "#6CBEC7";
        break;
      case 4:
        color = "#FF7203";
        break;
      case 5:
        color = "#F33962";
        break;
      case 6:
        color = "#F8D9CF";
        break;
      default:
        color = "#FFFFFF";
    }
    return {
      ...item,
      color,
    };
  });

  const legendData = colorLegend.map((legend) => (
    <div class="flex items-center justify-between min-w-56 mb-3 font-outfit">
      <div class="flex items-center">
        <div class="!w-3 !h-3 rounded-full mr-2" style={`background:${legend.color}`} />
        <span class="text-sm text-white">{legend.name}</span>
      </div>
      <span class="text-sm text-white">{formatValue(legend.value)}</span>
    </div>
  ));

  return (
    <div class="flex justify-between w-full">
      <div ref={refDiv} class="h-72 w-full"></div>
      <div class="w-full items-center flex-col flex justify-center">
        <For each={legendData}>{(legend) => legend}</For>
      </div>
    </div>
  );
};

export default CauseCodeDetailsChart;
