import { Component, createEffect, For } from "solid-js";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Dark from "@amcharts/amcharts5/themes/Dark";

const APNTrendChart: Component = () => {
  let refDiv: any;
  let root: any;

  const trendData = [
    { date: "2024/09/01", apn1: 450, apn2: 400, apn3: 600, other: 300 },
    { date: "2024/09/02", apn1: 550, apn2: 450, apn3: 550, other: 350 },
    { date: "2024/09/03", apn1: 500, apn2: 500, apn3: 500, other: 400 },
    { date: "2024/09/04", apn1: 400, apn2: 450, apn3: 600, other: 350 },
    { date: "2024/09/05", apn1: 450, apn2: 480, apn3: 540, other: 380 },
    { date: "2024/09/06", apn1: 620, apn2: 500, apn3: 480, other: 420 },
    { date: "2024/09/07", apn1: 590, apn2: 450, apn3: 460, other: 390 },
    { date: "2024/09/08", apn1: 470, apn2: 410, apn3: 420, other: 350 },
  ];

  createEffect(() => {
    if (root) {
      root.dispose();
    }
    createChart();
  });

  const createChart = () => {
    root = am5.Root.new(refDiv);
    root.setThemes([am5themes_Dark.new(root)]);
    root._logo?.dispose();

    let chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        layout: root.verticalLayout,
        panX: true,
        panY: false,
        wheelX: "panX",
        wheelY: "none",
      })
    );

    let dateAxis = chart.xAxes.push(
      am5xy.DateAxis.new(root, {
        baseInterval: { timeUnit: "day", count: 1 },
        renderer: am5xy.AxisRendererX.new(root, {
          minGridDistance: 50,
          strokeOpacity: 0.2,
          stroke: am5.color(0xffffff),
        }),
      })
    );

    let valueAxis = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        renderer: am5xy.AxisRendererY.new(root, {
          strokeOpacity: 0.2,
          stroke: am5.color(0xffffff),
        }),
      })
    );

    const createSeries = (name: string, field: keyof (typeof trendData)[0], color: string) => {
      let series = chart.series.push(
        am5xy.SmoothedXYLineSeries.new(root, {
          name: name,
          xAxis: dateAxis,
          yAxis: valueAxis,
          valueYField: field,
          valueXField: "date",
          stroke: am5.color(color),
          fill: am5.color(color),
        })
      );

      series.strokes.template.setAll({
        strokeWidth: 3,
        shadowColor: am5.color(color),
        shadowBlur: 30,
        shadowOffsetX: 0,
        shadowOffsetY: 0,
      });

      series.fills.template.setAll({
        visible: true,
        fillOpacity: 0.6,
      });

      series.fills.template.set(
        "fillGradient",
        am5.LinearGradient.new(root, {
          stops: [
            { color: am5.color(color), offset: 0 },
            { color: am5.color(0x1f1e29), offset: 1 },
          ],
        })
      );

      series.data.setAll(
        trendData.map((data) => ({
          date: new Date(data.date).getTime(),
          [field]: data[field],
        }))
      );
    };

    createSeries("APN 812081202", "apn1", "#EFDD00");
    createSeries("APN 812081203", "apn2", "#4379F2");
    createSeries("APN 812081204", "apn3", "#BD2EEE");
    createSeries("Other", "other", "#6CBEC7");

    let cursor = chart.set("cursor", am5xy.XYCursor.new(root, {}));
    cursor.lineY.setAll({
      stroke: am5.color(0xffffff),
      strokeDasharray: [3, 3],
    });
  };

  const colorLegend = [
    { name: "APN 812081202", color: "#EFDD00" },
    { name: "APN 812081203", color: "#4379F2" },
    { name: "APN 812081204", color: "#BD2EEE" },
    { name: "Other", color: "#6CBEC7" },
  ];

  const legendData = colorLegend.map((legend) => (
    <div class="flex items-center mx-4">
      <div class="!min-w-3 !min-h-3 rounded-full mr-2" style={`background:${legend.color}`} />
      <span class="text-sm text-white">{legend.name}</span>
    </div>
  ));

  return (
    <div class="w-full">
      <div ref={refDiv} class="h-64 w-full"></div>
      <div class="flex justify-center items-center mt-4">
        <For each={legendData}>{(legend) => legend}</For>
      </div>
    </div>
  );
};

export default APNTrendChart;
