import { Component } from "solid-js";
import APNDistribution from "./APNDistributionChart";
import APNTrendChart from "./APNTrendChart";
import FailedSessionTable from "./FailedSessionTable";

const FailedOutboundPopup: Component<{ onClose: () => void }> = (props) => {
  return (
    <div class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div class="bg-neutral-700 backdrop-blur-md border-[1px] border-neutral-200 bg-opacity-20 p-6 rounded-2xl w-11/12 h-5/6  overflow-y-scroll">
        <div class="flex items-start justify-between mb-4">
          <div class="flex flex-col">
            <h2 class="text-lg font-semibold text-white">Failed Outbond by Cause Code</h2>
            <span class="text-white text-sm">APN Access Denied</span>
          </div>

          <button onClick={props.onClose} class="text-white text-lg">
            <img src="/src/assets/svg/globalicon/close.svg" alt="Close" />
          </button>
        </div>
        <div>
          <div class="md:hidden lg:block">
            <div class="grid grid-cols-2 gap-4">
              <div class="bg-black p-4 rounded-xl">
                <h3 class="text-md font-semibold text-white mb-3">APN Distribution</h3>
                <APNDistribution />
              </div>
              <div class="bg-black p-4 rounded-xl">
                <h3 class="text-md font-semibold text-white mb-3">APN Distribution Trend</h3>
                <APNTrendChart />
              </div>
              <div class="bg-black p-4 rounded-xl col-span-2">
                <div class="flex justify-between items-center mb-4">
                  <h3 class="text-md font-semibold text-white">Session Success Rate Details</h3>
                  <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
                </div>
                <FailedSessionTable />
              </div>
            </div>
          </div>
          <div class="md:block lg:hidden">
            <div class="flex flex-col gap-4">
              <div class="bg-black p-4 rounded-xl">
                <h3 class="text-md font-semibold text-white mb-3">APN Distribution</h3>
                <APNDistribution />
              </div>
              <div class="bg-black p-4 rounded-xl">
                <h3 class="text-md font-semibold text-white mb-3">APN Distribution Trend</h3>
                <APNTrendChart />
              </div>
              <div class="bg-black p-4 rounded-xl col-span-2">
                <div class="flex justify-between items-center mb-4">
                  <h3 class="text-md font-semibold text-white">Session Success Rate Details</h3>
                  <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
                </div>
                <FailedSessionTable />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FailedOutboundPopup;
