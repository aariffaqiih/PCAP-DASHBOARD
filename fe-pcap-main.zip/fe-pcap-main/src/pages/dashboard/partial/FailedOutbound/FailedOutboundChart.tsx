import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import * as am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import { onCleanup, onMount } from "solid-js";

const FailedOutboundChart = () => {
  let chartRoot: string | HTMLElement;

  onMount(() => {
    let root = am5.Root.new(chartRoot);

    root.setThemes([am5themes_Animated.default.new(root)]);
    if (root._logo) {
      root._logo.dispose();
    }
    let chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        panX: true,
        panY: true,
        wheelX: "panX",
        wheelY: "zoomX",
        layout: root.verticalLayout,
      })
    );

    let xAxis = chart.xAxes.push(
      am5xy.CategoryAxis.new(root, {
        categoryField: "category",
        renderer: am5xy.AxisRendererX.new(root, {
          minGridDistance: 30,
          opposite: false,
        }),
        tooltip: am5.Tooltip.new(root, {}),
      })
    );

    xAxis.get("renderer").labels.template.setAll({
      fill: am5.color(0xffffff),
      textAlign: "center",
      centerX: am5.p50,
      oversizedBehavior: "wrap",
      text: "{category}",
    });

    chart.events.on("wheel", () => {
      const categoryWidth = chart.plotContainer.width() / xAxis.dataItems.length;
      xAxis.get("renderer").labels.template.setAll({
        maxWidth: categoryWidth - 10,
      });
    });

    let yAxis = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        renderer: am5xy.AxisRendererY.new(root, {
          strokeOpacity: 0.5,
          opposite: true,
        }),
      })
    );

    yAxis.get("renderer").labels.template.setAll({
      fill: am5.color(0xffffff),
    });

    let series = chart.series.push(
      am5xy.ColumnSeries.new(root, {
        xAxis: xAxis,
        yAxis: yAxis,
        valueYField: "value",
        categoryXField: "category",
        fill: am5.color(0x466eff),
        clustered: false,
        tooltip: am5.Tooltip.new(root, {
          labelText: "{categoryX}: [bold]{valueY}[/]",
        }),
      })
    );

    series.columns.template.setAll({
      width: 28,
      cornerRadiusTL: 8,
      cornerRadiusTR: 8,
      strokeWidth: 2,
    });

    let data = [
      { category: "APN Access Denied", value: 200 },
      { category: "Context Not Found", value: 300 },
      { category: "Invalid Peer", value: 150 },
      { category: "Missing or Unknown APN", value: 250 },
      { category: "New PDN Type due to Network Reference", value: 400 },
      { category: "Request Rejected", value: 350 },
      { category: "Unable to Page UE", value: 600 },
      { category: "User Authentication Failed", value: 1000 },
    ];

    const wrapTextEveryThreeWords = (text: string) => {
      const words = text.split(" ");
      return words.reduce((acc, word, index) => {
        return acc + word + ((index + 1) % 2 === 0 ? "\n" : " ");
      }, "");
    };

    const modifiedData = data.map((item) => ({
      ...item,
      category: wrapTextEveryThreeWords(item.category),
    }));

    xAxis.data.setAll(modifiedData);
    series.data.setAll(modifiedData);

    let legend = chart.children.push(
      am5.Legend.new(root, {
        layout: root.horizontalLayout,
        paddingBottom: 20,
        useDefaultMarker: true,
      })
    );

    legend.labels.template.setAll({
      maxWidth: 150,
      fontSize: 12,
      fill: am5.color(0xffffff),
    });

    onCleanup(() => {
      root.dispose();
    });
  });

  return (
    <div
      ref={(el) => {
        chartRoot = el;
      }}
      style={{ width: "100%", height: "384px" }}
    ></div>
  );
};

export default FailedOutboundChart;
