import { Component, createSignal } from "solid-js";
import Header from "../../assets/components/header";
import Sidenav from "../../assets/components/sidenav/sidenav";
import EDCTransactions from "./partial/EDCTransactions";
import RealtimeSessionChart from "./partial/RealtimeSession/realtimesession";
import RealtimeTransactionChart from "./partial/RealtimeTransaction/realtimetransaction";
import TransactionAccepted from "./partial/RealtimeTransaction/TransactionAccepted";
import TransactionFailed from "./partial/RealtimeTransaction/TransactionFailed";
import TransactionMap from "./partial/TransactionDIstribution/TransactionMap";
import FailedOutboundChart from "./partial/FailedOutbound/FailedOutboundChart";
import FailedOutboundPopup from "./partial/FailedOutbound/FailedOutboundPopup";
import SessionAccepted from "./partial/RealtimeSession/SessionAccepted";
import SessionFailed from "./partial/RealtimeSession/SessionFailed";
import TransactionMapPopup from "./partial/TransactionDIstribution/TransacrionDistributionPopup";
import { username } from "../../stores/authStore";
import Flatpickr from "flatpickr";
import "flatpickr/dist/flatpickr.min.css";
import { Instance } from "flatpickr/dist/types/instance";

const Dashboard: Component = () => {
  const [showSessionPopup, setShowSessionPopup] = createSignal(false);
  const [showTransactionPopup, setShowTransactionPopup] = createSignal(false);
  const [showFailedOutboundPopup, setShowFailedOutboundPopup] = createSignal(false);
  const [showSessionFailed, setShowSessionFailed] = createSignal(false);
  const [showSessionAccepted, setShowSessionAccepted] = createSignal(false);
  const [showTransactionMapPopup, setShowTransactionMapPopup] = createSignal(false);
  const [isTransactionOpen, setIsTransactionOpen] = createSignal(false);
  const [isTerritoryOpen, setIsTerritoryOpen] = createSignal(false);
  const [selectedTransaction, setSelectedTransaction] = createSignal("Transaction");
  const [selectedTerritory, setSelectedTerritory] = createSignal("Territory");
  const [startDate, setStartDate] = createSignal<Date | null>(null);
  const [endDate, setEndDate] = createSignal<Date | null>(null);

  let startPickerRef: HTMLInputElement | undefined;
  let endPickerRef: HTMLInputElement | undefined;

  const initFlatpickr = () => {
    if (startPickerRef) {
      Flatpickr(startPickerRef, {
        onChange: (selectedDates) => setStartDate(selectedDates[0]),
      });
    }
    if (endPickerRef) {
      Flatpickr(endPickerRef, {
        onChange: (selectedDates) => setEndDate(selectedDates[0]),
      });
    }
  };
  setTimeout(initFlatpickr, 0);

  const toggleTransactionDropdown = () => setIsTransactionOpen(!isTransactionOpen());
  const toggleTerritoryDropdown = () => setIsTerritoryOpen(!isTerritoryOpen());

  const handleTransactionSelect = (option: string) => {
    setSelectedTransaction(option);
    setIsTransactionOpen(false);
  };

  const handleTerritorySelect = (option: string) => {
    setSelectedTerritory(option);
    setIsTerritoryOpen(false);
  };

  const handleLineClick = (type: string) => {
    if (type === "accepted") {
      setShowSessionAccepted(true);
    } else if (type === "failed") {
      setShowSessionFailed(true);
    }
  };
  const handleTransactionLineClick = (type: string) => {
    if (type === "accepted") {
      setShowTransactionAccepted(true);
    } else if (type === "failed") {
      setShowTransactionFailed(true);
    }
  };
  const openTransactionMapPopup = () => {
    setShowTransactionMapPopup(true);
  };

  const openSessionPopup = () => {
    setShowSessionPopup(true);
    setShowTransactionPopup(false);
  };
  const [showTransactionAccepted, setShowTransactionAccepted] = createSignal(false);
  const [showTransactionFailed, setShowTransactionFailed] = createSignal(false);
  const openTransactionPopup = () => {
    setShowTransactionPopup(true);
    setShowSessionPopup(false);
  };

  const openFailedOutboundPopup = () => {
    setShowFailedOutboundPopup(true);
  };

  const closeFailedOutboundPopup = () => setShowFailedOutboundPopup(false);

  return (
    <div class="font-outfit bg-[#110F17] flex h-screen">
      <Sidenav />
      <div class="flex-grow p-5 overflow-y-auto">
        <Header title="Summary Transaction" />
        <div class="flex flex-col xl:flex-row gap-5">
          <div class="flex flex-col gap-4 w-full xl:w-5/12 h-full">
            <div class="bg-[#1F1E29] p-6 rounded-2xl">
              <h2 class="text-lg font-semibold text-white mb-5">EDC Transactions</h2>

              <EDCTransactions />
            </div>
            <div class="grid grid-cols-1 gap-6">
              <div class="bg-[#1F1E29] p-6 rounded-2xl">
                <div class="flex justify-between items-center mb-4">
                  <h2 class="text-lg font-semibold text-white">Realtime Session Success</h2>
                  <button>
                    <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
                  </button>
                </div>
                <div class="cursor-pointer" onClick={openSessionPopup}>
                  <RealtimeSessionChart chartId="realtimeSessionChart" onLineClick={handleLineClick} />
                </div>
                <div class="h-7"></div>
                <div class="flex justify-between items-center mb-4">
                  <h2 class="text-lg font-semibold text-white">Realtime Transaction Success</h2>
                  <button>
                    <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
                  </button>
                </div>
                <div class="cursor-pointer" onClick={openTransactionPopup}>
                  <RealtimeTransactionChart chartId="realtime-transaction-chart" onLineClick={handleTransactionLineClick} />
                </div>
              </div>
            </div>
          </div>
          <div class="flex flex-col gap-4 w-full xl:w-7/12">
            <div class="bg-[#1F1E29] p-6 rounded-2xl w-full h-3/5">
              <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-semibold text-white">Transaction Distribution</h2>
                <select class="bg-[#1F1E29] border-[1px] border-[#3E3E47] p-3 rounded-full text-white focus:outline-none">
                  <option>ALL</option>
                  <option>Success</option>
                  <option>Failed</option>
                </select>
              </div>
              <div class="cursor-pointer" onClick={openTransactionMapPopup}>
                <TransactionMap />
              </div>

              <div class="mt-6 mx-6 text-sm text-white flex justify-between">
                <div class="flex gap-3 items-center">
                  <div class="min-w-3 min-h-3 rounded-full bg-[#72BF78]"></div>
                  <p>{">90K Transaction"}</p>
                </div>
                <div class="flex gap-3 items-center">
                  <div class="min-w-3 min-h-3 rounded-full bg-[#A0D683]"></div>
                  <p>50K - 90K Transaction</p>
                </div>
                <div class="flex gap-3 items-center">
                  <div class="min-w-3 min-h-3 rounded-full bg-[#FEFF9F]"></div>
                  <p>{"<50K Transaction"}</p>
                </div>
              </div>
            </div>
            <div class="bg-[#1F1E29] p-6 rounded-2xl col-span-2 w-full h-2/5">
              <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-semibold text-white">Failed Outbound by Cause Code</h2>
                <button>
                  <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
                </button>
              </div>
              <div class="cursor-pointer" onClick={openFailedOutboundPopup}>
                <FailedOutboundChart />
              </div>
            </div>
          </div>
        </div>
      </div>
      {showSessionAccepted() && <SessionAccepted onClose={() => setShowSessionAccepted(false)} />}
      {showSessionFailed() && <SessionFailed onClose={() => setShowSessionFailed(false)} />}
      {showTransactionAccepted() && <TransactionAccepted onClose={() => setShowTransactionAccepted(false)} />}
      {showTransactionFailed() && <TransactionFailed onClose={() => setShowTransactionFailed(false)} />}
      {showFailedOutboundPopup() && <FailedOutboundPopup onClose={closeFailedOutboundPopup} />}
      {showTransactionMapPopup() && <TransactionMapPopup onClose={() => setShowTransactionMapPopup(false)} />}
    </div>
  );
};
export default Dashboard;
