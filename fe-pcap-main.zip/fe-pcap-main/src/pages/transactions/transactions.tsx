import { Component, createSignal } from "solid-js";
import Header from "../../assets/components/header";
import Sidenav from "../../assets/components/sidenav/sidenav";
import Popup from "./partial/detailsession";
import TransactionTable from "./partial/TransactionTable";

const Transactions: Component = () => {
  const [isPopupOpen, setPopupOpen] = createSignal(false);
  const [selectedTransaction, setSelectedTransaction] = createSignal(null);

  const openPopup = (transaction: any) => {
    setSelectedTransaction(transaction);
    setPopupOpen(true);
  };

  const closePopup = () => {
    setPopupOpen(false);
    setSelectedTransaction(null);
  };

  return (
    <div class="font-outfit bg-[#110F17] flex h-screen">
      <Sidenav />
      <div class="flex-grow p-5 overflow-y-auto">
        <Header title="EDC Transactions List" />
        <div class="h-[calc(100vh-140px)] w-full bg-[#1F1E29] p-6 rounded-2xl ag-theme-alpine-dark">
          <div class="flex justify-between items-center mb-5">
            <h1 class="text-xl font-medium font-outfit">EDC Session</h1>
            <div class="flex items-center space-x-4">
              <select class="bg-[#1F1E29] border-[1px] border-[#3E3E47] px-3 py-2 rounded-full text-white focus:outline-none">
                <option>Search</option>
                <option>Searchnya pake dropdown?</option>
                <option>Lorem ipsum</option>
              </select>
            </div>
          </div>

          <TransactionTable onOpenPopup={openPopup} />
        </div>

        <Popup isOpen={isPopupOpen()} onClose={closePopup} transaction={selectedTransaction() || {}} />
      </div>
    </div>
  );
};

export default Transactions;
