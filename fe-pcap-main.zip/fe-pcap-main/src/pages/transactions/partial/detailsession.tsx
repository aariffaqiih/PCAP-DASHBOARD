import { Component, createSignal } from "solid-js";
import AgGridSolid from "ag-grid-solid";
import TransactionDetailsPopup from "./TransactionDetailsPopup";

interface PopupProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: any;
}

const Popup: Component<PopupProps> = (props) => {
  const [isDetailsPopupOpen, setDetailsPopupOpen] = createSignal(false);

  const openDetailsPopup = () => setDetailsPopupOpen(true);
  const closeDetailsPopup = () => setDetailsPopupOpen(false);

  const detailSessionData = Array(10).fill({
    teId: "8120812081208120",
    timestamp: "2024-03-04 09:30:25, 284657",
    gtpCommand: "Delete Bearer Request",
    status: "Success",
    imsi: "081887990007",
    rootcause: "Create Session Request",
    hwDest: "Detail Transaction",
  });

  const columnDefs = [
    {
      field: "teId",
      headerName: "TE ID",
      headerCheckboxSelection: true,
      checkboxSelection: true,
      flex: 1,
      minWidth: 200,
      headerClass: "bg-gray-500 text-white text-center font-semibold",
      cellClass: "text-white text-center",
    },
    {
      field: "timestamp",
      headerName: "Timestamp",
      flex: 2,
      minWidth: 200,
      headerClass: "bg-gray-500 text-white text-center font-semibold",
      cellClass: "text-white text-center",
    },
    {
      field: "gtpCommand",
      headerName: "GTP Command",
      flex: 1,
      minWidth: 200,
      headerClass: "bg-gray-500 text-white text-center font-semibold",
      cellClass: "text-white text-center",
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
      minWidth: 100,
      headerClass: "bg-gray-500 text-white text-center font-semibold",
      cellClass: (params: any) => (params.value === "Success" ? "text-green-500 font-bold text-center" : "text-red-500 font-bold text-center"),
    },
    {
      field: "imsi",
      headerName: "IMSI",
      flex: 1,
      minWidth: 150,
      headerClass: "bg-gray-500 text-white text-center font-semibold",
      cellClass: "text-white text-center",
    },
    {
      field: "rootCause",
      headerName: "Rootcause",
      flex: 1,
      minWidth: 200,
      headerClass: "bg-gray-500 text-white text-center font-semibold",
      cellClass: "text-white text-center",
    },
    {
      headerName: "HW Dest",
      field: "hwDest",
      minWidth: 200,
      cellRenderer: () => (
        <button onClick={openDetailsPopup} style={{ display: "flex", "align-items": "center", "justify-content": "center" }}>
          <img src="/src/assets/svg/buttons/DetailSession.svg" alt="Detail Sessions" />
        </button>
      ),
      cellStyle: { display: "flex", alignItems: "center", justifyContent: "center" },
    },
  ];

  const gridOptions = {
    rowHeight: 62.5,
  };

  return (
    <>
      {props.isOpen && (
        <div class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-10">
          <div class="bg-neutral-700 backdrop-blur-md border-[1px] border-neutral-200 bg-opacity-20 p-6 rounded-2xl w-11/12 h-5/6  overflow-y-scroll">
            <div class="flex justify-between items-center mb-4">
              <div>
                <h2 class="text-2xl font-semibold text-white">Session Success Rate Details</h2>
                <p class="text-gray-400">2024-09-19, Success Sessions</p>
              </div>

              <div class="flex gap-4">
                <select class="bg-[#1F1E29] border-[1px] border-[#3E3E47] px-3 py-2 rounded-full text-white focus:outline-none">
                  <option>Success Session</option>
                  <option>Failed Session</option>
                  <option>ALL</option>
                </select>
                <button onClick={props.onClose}>
                  <img src="/src/assets/svg/globalicon/close.svg" alt="Close" />
                </button>
              </div>
            </div>
            <div class="bg-black p-4 rounded-xl">
              <div class="flex justify-between items-center mb-4">
                <h3 class="text-md font-semibold text-white">Session Success Rate Details</h3>
                <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
              </div>
              <div class="h-[400px] mt-5 ag-theme-alpine-dark">
                <AgGridSolid
                  rowData={detailSessionData}
                  columnDefs={columnDefs}
                  gridOptions={gridOptions}
                  defaultColDef={{
                    flex: 1,
                    minWidth: 100,
                    resizable: true,
                    sortable: true,
                    headerClass: "bg-[#828690] text-white text-center font-semibold",
                  }}
                  rowSelection="multiple"
                  suppressRowClickSelection={true}
                  domLayout="normal"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      <TransactionDetailsPopup isOpen={isDetailsPopupOpen()} onClose={closeDetailsPopup} />
    </>
  );
};

export default Popup;
