import { Component, createSignal } from "solid-js";
import AgGridSolid from "ag-grid-solid";

interface TransactionTableProps {
  onOpenPopup: (transaction: any) => void;
}

const TransactionTable: Component<TransactionTableProps> = (props) => {
  const generateTransactionData = () => {
    const data = Array(15)
      .fill(null)
      .map(() => {
        const total = Math.floor(Math.random() * 50000) + 10000;
        const success = Math.floor(total * (Math.random() * 0.9 + 0.1));
        const failed = total - success;
        const successRate = `${Math.round((success / total) * 100)}%`;
        const failedRate = `${Math.round((failed / total) * 100)}%`;

        const mnc = Math.floor(Math.random() * 100)
          .toString()
          .padStart(2, "0");
        const mcc = Math.floor(Math.random() * 1000)
          .toString()
          .padStart(3, "0");

        return {
          apn: `edcbactsel.mnc${mnc}.mcc${mcc}.gprs`,
          total: total.toLocaleString(),
          success: success.toLocaleString(),
          failed: failed.toLocaleString(),
          successRate,
          failedRate,
        };
      });
    return data;
  };

  const [rowData] = createSignal(generateTransactionData());

  const columnDefs = [
    {
      headerCheckboxSelection: true,
      checkboxSelection: true,
      width: 50,
      headerClass: "bg-gray-500 text-white",
      cellClass: "text-center",
      cellStyle: { textAlign: "center" },
      maxWidth: 50,
    },
    { headerName: "APN Name", field: "apn", cellClass: "text-white text-center px-4 py-2 font-outfit", minWidth: 400 },
    { headerName: "Total Session", field: "total", cellClass: "text-white text-center px-4 py-2 font-outfit", minWidth: 150 },
    { headerName: "Success Session", field: "success", cellClass: "text-white text-center px-4 py-2 font-outfit", minWidth: 150 },
    { headerName: "Failed Session", field: "failed", cellClass: "text-white text-center px-4 py-2 font-outfit", minWidth: 150 },
    { headerName: "Success Rate", field: "successRate", cellClass: "text-white text-center px-4 py-2 font-outfit", minWidth: 150 },
    { headerName: "Failed Rate", field: "failedRate", cellClass: "text-white text-center px-4 py-2 font-outfit", minWidth: 150 },
    {
      headerName: "Detail",
      cellRenderer: (params: any) => (
        <button onClick={() => props.onOpenPopup(params.data)}>
          <img src="/src/assets/svg/buttons/DetailTransaction.svg" alt="Detail Sessions" />
        </button>
      ),
      width: 150,
      cellClass: "text-center pt-3.5",
      minWidth: 200,
    },
  ];

  const gridOptions = {
    rowHeight: 62.5,
  };

  return (
    <div class="ag-theme-alpine-dark font-outfit h-[calc(100%-50px)] w-full">
      <AgGridSolid
        rowData={rowData()}
        columnDefs={columnDefs}
        gridOptions={gridOptions}
        defaultColDef={{
          flex: 1,
          minWidth: 100,
          resizable: true,
          sortable: true,
          headerClass: "bg-gray-500 text-white text-center font-semibold px-4 py-3 font-outfit",
        }}
        rowSelection="multiple"
        suppressRowClickSelection={true}
        domLayout="normal"
      />
    </div>
  );
};

export default TransactionTable;
