import { Component } from "solid-js";
import EDCTransactionTable from "./EDCTransactionTable";

interface TransactionDetailsPopupProps {
  isOpen: boolean;
  onClose: () => void;
}

const TransactionDetailsPopup: Component<TransactionDetailsPopupProps> = (props) => {
  return (
    <>
      {props.isOpen && (
        <div class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div class="bg-neutral-700 backdrop-blur-md border-[1px] border-neutral-200 bg-opacity-20 p-6 rounded-2xl w-11/12 h-5/6  overflow-y-scroll">
            <div class="flex justify-between items-center">
              <div class="flex flex-col gap-2">
                <h2 class="text-lg font-semibold text-white">Session Success Rate Details</h2>
                <h2 class="text-xs font-semibold text-[#C5C4C7]">2024-09-19, Failed Session</h2>
              </div>
              <button onClick={props.onClose}>
                <img src="/src/assets/svg/globalicon/close.svg" alt="Close" />
              </button>
            </div>

            <div class="mt-5">
              <div class="bg-black rounded-lg p-5 mb-5">
                <p class="text-white font-semibold">EDC Transaction Flow</p>
                bisa ditaruh sini ya mas FE
              </div>

              <EDCTransactionTable />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default TransactionDetailsPopup;
