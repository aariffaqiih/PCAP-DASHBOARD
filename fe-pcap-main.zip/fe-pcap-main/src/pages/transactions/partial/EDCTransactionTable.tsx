import { Component } from "solid-js";
import AgGridSolid from "ag-grid-solid";
import "ag-grid-community/styles/ag-grid.css";

const detailSessionData = Array(5).fill({
  teId: "8120812081208120",
  timestamp: "2024-03-04 09:30:25, 284657",
  sourceIp: "221.132.217.127",
  destIp: "221.132.217.127",
  protocol: "GPTv2",
  status: "Success",
  apn: "edcbactsel.mnc10.mcc510.gprs",
  hwDest: "MS-NLB-PhysServer-01_17:e8:00",
});

const columnDefs = [
  { headerCheckboxSelection: true, checkboxSelection: true, width: 50 },
  { headerName: "TE ID", field: "teId", minWidth: 150, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
  { headerName: "Timestamp", field: "timestamp", minWidth: 200, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
  { headerName: "Source IP", field: "sourceIp", minWidth: 150, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
  { headerName: "Destination IP", field: "destIp", minWidth: 150, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
  { headerName: "Protocol", field: "protocol", minWidth: 100, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
  { headerName: "Status", field: "status", cellStyle: { color: "green", fontWeight: "bold" }, minWidth: 100, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
  { headerName: "APN", field: "apn", minWidth: 200, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
  { headerName: "HW Dest", field: "hwDest", minWidth: 200, headerClass: "bg-gray-500 text-white text-center font-semibold", cellClass: "text-white text-center" },
];

const gridOptions = {
  rowHeight: 62.5,
};

const EDCTransactionTable: Component = () => {
  return (
    <div class="bg-black p-4 rounded-xl">
      <div class="flex justify-between items-center mb-4">
        <h3 class="text-md font-semibold text-white">Session Transaction Details</h3>
        <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-EXPORT.svg" alt="Export" />
      </div>
      <div class="ag-theme-alpine-dark h-96 rounded-lg">
        <AgGridSolid
          rowData={detailSessionData}
          columnDefs={columnDefs}
          gridOptions={gridOptions}
          defaultColDef={{
            flex: 1,
            minWidth: 100,
            resizable: true,
            sortable: true,
            headerClass: "bg-[#828690] text-white text-center font-semibold",
          }}
          rowSelection="multiple"
          suppressRowClickSelection={true}
          domLayout="normal"
        />
      </div>
    </div>
  );
};

export default EDCTransactionTable;
