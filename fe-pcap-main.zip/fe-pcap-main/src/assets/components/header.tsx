import { Component, createSignal, onMount } from "solid-js";
import { username } from "../../stores/authStore";
import Flatpickr from "flatpickr";
import "flatpickr/dist/flatpickr.min.css";
import "./header.css";
const Header: Component<{ title: string }> = (props) => {
  const [startDate, setStartDate] = createSignal<Date | null>(null);
  const [endDate, setEndDate] = createSignal<Date | null>(null);
  let startPickerRef: HTMLInputElement | undefined;
  let endPickerRef: HTMLInputElement | undefined;

  onMount(() => {
    if (startPickerRef) {
      Flatpickr(startPickerRef, {
        onChange: (selectedDates) => setStartDate(selectedDates[0]),
      });
    }
    if (endPickerRef) {
      Flatpickr(endPickerRef, {
        onChange: (selectedDates) => setEndDate(selectedDates[0]),
      });
    }
  });

  return (
    <header class="flex flex-wrap flex-col xl:flex-row justify-between xl:items-center mb-6 gap-4">
      <div class="w-full xl:w-auto">
        <h1 class="text-2xl md:text-3xl font-bold text-white">{props.title}</h1>
        <p class="text-[#C5C4C7] text-sm mt-1">All Country - Network A - 19/09/2024 - 24/09/2024</p>
      </div>

      <div class="flex flex-wrap gap-4 items-center xl:justify-end w-full xl:w-auto">
        <select class="bg-[#1F1E29] p-2 md:p-3 border-[1px] border-[#28272F] rounded-full text-white focus:outline-none text-sm md:text-base">
          <option>Transaction</option>
          <option>Transaction A</option>
          <option>Transaction B</option>
        </select>

        <select class="bg-[#1F1E29] p-2 md:p-3 border-[1px] border-[#28272F] rounded-full text-white focus:outline-none text-sm md:text-base">
          <option>Territory</option>
          <option>x</option>
          <option>y</option>
        </select>

        <div class="flex items-center bg-[#1F1E29] p-2 md:p-3 border-[1px] border-[#28272F] rounded-full">
          <input ref={startPickerRef} class="flatpickr-input bg-transparent text-white text-sm md:text-base outline-none placeholder-white w-full" placeholder="Select Start Date" />
        </div>

        <div class="flex items-center bg-[#1F1E29] p-2 md:p-3 border-[1px] border-[#28272F] rounded-full">
          <input ref={endPickerRef} class="flatpickr-input bg-transparent text-white text-sm md:text-base outline-none placeholder-white w-full" placeholder="Select End Date" />
        </div>

        <div class="flex items-center gap-2 bg-[#1F1E29] py-2 md:py-3 pl-3 pr-5 border-[1px] border-[#28272F] rounded-full">
          <img src="/src/assets/profilePicture.png" class="w-8 h-8 md:w-10 md:h-10 rounded-full" alt="Profile Picture" />
          <div class="flex flex-col">
            <span class="text-white font-medium text-sm md:text-base min-w-max">User LDAP</span>
            <span class="text-[#C5C4C7] text-xs min-w-max">@{username() || "username"}</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
