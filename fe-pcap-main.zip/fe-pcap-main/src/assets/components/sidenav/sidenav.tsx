import { Component } from "solid-js";
import { useNavigate, useLocation } from "@solidjs/router";

const Sidenav: Component = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div class="ml-4 flex flex-col justify-center">
      <button>
        <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/LOGO/PCAP-TELKOMSEL.svg" alt="LOGO PCAP TELKOMSEL" class="absolute top-3 max-w-12 xl:max-w-20" onClick={() => navigate("/login")} />
      </button>

      <div class="flex flex-col gap-3 items-center justify-between bg-[#1F1E29] w-12 xl:w-20 h-max xl:h-[390px] border-[1px] border-[#28272F] rounded-full py-2 xl:py-4">
        <a
          href="#"
          class={`sidenav-item flex items-center justify-center ${isActive("/dashboard") ? "w-[48px] h-[48px] rounded-full" : ""}`}
          style={isActive("/dashboard") ? "background: radial-gradient(72.45% 72.45% at 27.78% 24.07%, #FABC3F 0%, #E85C0D 60.46%, #C7253E 79.62%, #821131 100%);" : ""}
          onClick={() => navigate("/dashboard")}
        >
          <img src="/src/assets/svg/iconnav/menu1.svg" alt="Dashboard Icon" />
        </a>
        <a
          href="#"
          class={`sidenav-item flex items-center justify-center ${isActive("/transactions") ? "w-[48px] h-[48px] rounded-full" : ""}`}
          style={isActive("/transactions") ? "background: radial-gradient(72.45% 72.45% at 27.78% 24.07%, #FABC3F 0%, #E85C0D 60.46%, #C7253E 79.62%, #821131 100%);" : ""}
          onClick={() => navigate("/transactions")}
        >
          <img src="/src/assets/svg/iconnav/menu2.svg" alt="Transactions Icon" />
        </a>
        <a
          href="#"
          class={`sidenav-item flex items-center justify-center ${isActive("/analytics") ? "w-[48px] h-[48px] rounded-full" : ""}`}
          style={isActive("/analytics") ? "background: radial-gradient(72.45% 72.45% at 27.78% 24.07%, #FABC3F 0%, #E85C0D 60.46%, #C7253E 79.62%, #821131 100%);" : ""}
        >
          <img src="/src/assets/svg/iconnav/menu3.svg" alt="Analytics Icon" />
        </a>
        <div class="h-[1px] w-3/4 bg-[#D9D9D9]"></div>
        <a
          href="#"
          class={`sidenav-item flex items-center justify-center ${isActive("/settings") ? "w-[48px] h-[48px] rounded-full" : ""}`}
          style={isActive("/settings") ? "background: radial-gradient(72.45% 72.45% at 27.78% 24.07%, #FABC3F 0%, #E85C0D 60.46%, #C7253E 79.62%, #821131 100%);" : ""}
        >
          <img src="/src/assets/svg/iconnav/menu4.svg" alt="Settings Icon" />
        </a>
        <a
          href="#"
          class={`sidenav-item flex items-center justify-center ${isActive("/notifications") ? "w-[48px] h-[48px] rounded-full" : ""}`}
          style={isActive("/notifications") ? "background: radial-gradient(72.45% 72.45% at 27.78% 24.07%, #FABC3F 0%, #E85C0D 60.46%, #C7253E 79.62%, #821131 100%);" : ""}
        >
          <img src="/src/assets/svg/iconnav/menu5.svg" alt="Notifications Icon" />
        </a>
      </div>

      <button>
        <img src="https://raw.githubusercontent.com/aariffaqiih/IMG/refs/heads/main/BTN/PCAP-LOGOUT.svg" alt="LOGOUT" class="absolute bottom-3 max-w-12 xl:max-w-20" onClick={() => navigate("/login")} />
      </button>
    </div>
  );
};

export default Sidenav;
