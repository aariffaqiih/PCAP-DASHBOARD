// import type { Component } from 'solid-js';
// import Routing from '../src/routes';
// import logo from './logo.svg';
// import styles from './App.module.css';

import { Component } from "solid-js";
import { Router } from "@solidjs/router";
import AppRoutes from "../src/routes/routing";
import Sidenav from "./assets/components/sidenav/sidenav";

const App: Component = () => {
  return (
    <Router>
      {/* <Sidenav /> */}
      <AppRoutes />
    </Router>
  );
  // return (
  //   <div class={styles.App}>
  //     <header class={styles.header}>
  //       {/* <img src={logo} class={styles.logo} alt="logo" />
  //       <p>
  //         Edit <code>src/App.tsx</code> and save to reload.
  //       </p>
  //       <a
  //         class={styles.link}
  //         href="https://github.com/solidjs/solid"
  //         target="_blank"
  //         rel="noopener noreferrer"
  //       >
  //         Learn Solid
  //       </a> */}
  //     </header>
  //   </div>
  // );
};

export default App;
